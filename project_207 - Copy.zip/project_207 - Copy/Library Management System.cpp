#include <windows.h>
#include <string>
#include <sstream>
using namespace std;

class Member {
public:
    int id;
    string name, email, phone, address;
    Member* next;

    Member(int i, string n, string e, string p, string a) {
        id = i;
        name = n;
        email = e;
        phone = p;
        address = a;
        next = NULL;
    }
};

class MemberList {
private:
    Member* head;

public:
    MemberList() {
        head = NULL;
    }

    void addMember(int id, string name, string email, string phone, string address) {
        Member* newMember = new Member(id, name, email, phone, address);

        if (head == NULL) {
            head = newMember;
        } else {
            Member* temp = head;
            while (temp->next != NULL)
                temp = temp->next;
            temp->next = newMember;
        }
    }

    bool removeMember(int id) {
        if (head == NULL)
            return false;

        if (head->id == id) {
            Member* del = head;
            head = head->next;
            delete del;
            return true;
        }

        Member* prev = head;
        Member* curr = head->next;

        while (curr != NULL) {
            if (curr->id == id) {
                prev->next = curr->next;
                delete curr;
                return true;
            }

            prev = curr;
            curr = curr->next;
        }

        return false;
    }

    string searchMember(int id) {
        Member* temp = head;

        while (temp != NULL) {
            if (temp->id == id) {
                stringstream ss;
                ss << "Member Found\r\n";
                ss << "ID: " << temp->id << "\r\n";
                ss << "Name: " << temp->name << "\r\n";
                ss << "Email: " << temp->email << "\r\n";
                ss << "Phone: " << temp->phone << "\r\n";
                ss << "Address: " << temp->address << "\r\n";
                return ss.str();
            }

            temp = temp->next;
        }

        return "Member not found.";
    }

    string displayMembers() {
        if (head == NULL)
            return "No members found.";

        stringstream ss;
        Member* temp = head;

        while (temp != NULL) {
            ss << "ID: " << temp->id << "\r\n";
            ss << "Name: " << temp->name << "\r\n";
            ss << "Email: " << temp->email << "\r\n";
            ss << "Phone: " << temp->phone << "\r\n";
            ss << "Address: " << temp->address << "\r\n";
            ss << "-------------------------\r\n";

            temp = temp->next;
        }

        return ss.str();
    }
};

class Book {
public:
    int bookID;
    string title, author;
    int copies;
    Book* left;
    Book* right;

    Book(int id, string t, string a, int c) {
        bookID = id;
        title = t;
        author = a;
        copies = c;
        left = NULL;
        right = NULL;
    }
};

class BookBST {
private:
    Book* root;

    Book* addHelper(Book* node, int id, string title, string author, int copies) {
        if (node == NULL)
            return new Book(id, title, author, copies);

        if (id < node->bookID)
            node->left = addHelper(node->left, id, title, author, copies);
        else if (id > node->bookID)
            node->right = addHelper(node->right, id, title, author, copies);

        return node;
    }

    Book* searchHelper(Book* node, int id) {
        if (node == NULL || node->bookID == id)
            return node;

        if (id < node->bookID)
            return searchHelper(node->left, id);

        return searchHelper(node->right, id);
    }

    Book* findMin(Book* node) {
        while (node != NULL && node->left != NULL)
            node = node->left;
        return node;
    }

    Book* removeHelper(Book* node, int id, bool& removed) {
        if (node == NULL)
            return NULL;

        if (id < node->bookID) {
            node->left = removeHelper(node->left, id, removed);
        }
        else if (id > node->bookID) {
            node->right = removeHelper(node->right, id, removed);
        }
        else {
            removed = true;

            if (node->left == NULL && node->right == NULL) {
                delete node;
                return NULL;
            }
            if (node->left == NULL) {
                Book* temp = node->right;
                delete node;
                return temp;
            }
            if (node->right == NULL) {
                Book* temp = node->left;
                delete node;
                return temp;
            }
            Book* minNode = findMin(node->right);

            node->bookID = minNode->bookID;
            node->title = minNode->title;
            node->author = minNode->author;
            node->copies = minNode->copies;

            bool dummy = false;
            node->right = removeHelper(node->right, minNode->bookID, dummy);
        }

        return node;
    }

    void inorder(Book* node, stringstream& ss) {
        if (node == NULL)
            return;

        inorder(node->left, ss);

        ss << "Book ID: " << node->bookID << "\r\n";
        ss << "Title: " << node->title << "\r\n";
        ss << "Author: " << node->author << "\r\n";
        ss << "Copies: " << node->copies << "\r\n";
        ss << "-------------------------\r\n";

        inorder(node->right, ss);
    }

public:
    BookBST() {
        root = NULL;
    }

    void addBook(int id, string title, string author, int copies) {
        root = addHelper(root, id, title, author, copies);
    }

    bool removeBook(int id) {
        bool removed = false;
        root = removeHelper(root, id, removed);
        return removed;
    }

    string searchBook(int id) {
        Book* result = searchHelper(root, id);

        if (result == NULL)
            return "Book not found.";

        stringstream ss;
        ss << "Book Found\r\n";
        ss << "Book ID: " << result->bookID << "\r\n";
        ss << "Title: " << result->title << "\r\n";
        ss << "Author: " << result->author << "\r\n";
        ss << "Copies: " << result->copies << "\r\n";

        return ss.str();
    }

    string displayBooksSorted() {
        if (root == NULL)
            return "No books found.";

        stringstream ss;
        inorder(root, ss);
        return ss.str();
    }
};

class BorrowRecord {
public:
    int memberID;
    int bookID;
    string date;
    BorrowRecord* next;
    BorrowRecord* prev;

    BorrowRecord(int m, int b, string d) {
        memberID = m;
        bookID = b;
        date = d;
        next = NULL;
        prev = NULL;
    }
};

class BorrowHistory {
private:
    BorrowRecord* head;
    BorrowRecord* tail;

public:
    BorrowHistory() {
        head = NULL;
        tail = NULL;
    }

    void addBorrowRecord(int memberID, int bookID, string date) {
        BorrowRecord* newRecord = new BorrowRecord(memberID, bookID, date);

        if (head == NULL) {
            head = tail = newRecord;
        } else {
            tail->next = newRecord;
            newRecord->prev = tail;
            tail = newRecord;
        }
    }

    string viewHistory(int memberID) {
        BorrowRecord* temp = head;
        bool found = false;
        stringstream ss;

        while (temp != NULL) {
            if (temp->memberID == memberID) {
                ss << "Member ID: " << temp->memberID << "\r\n";
                ss << "Book ID: " << temp->bookID << "\r\n";
                ss << "Borrow Date: " << temp->date << "\r\n";
                ss << "-------------------------\r\n";
                found = true;
            }

            temp = temp->next;
        }

        if (!found)
            return "No borrow history found for this member.";

        return ss.str();
    }
};

class ReturnStack {
private:
    int arr[100];
    int top;

public:
    ReturnStack() {
        top = -1;
    }

    bool pushReturn(int bookID) {
        if (top == 99)
            return false;

        top++;
        arr[top] = bookID;
        return true;
    }

    string processReturn() {
        if (top == -1)
            return "No returned books to process.";

        stringstream ss;
        ss << "Processing returned Book ID: " << arr[top];
        top--;

        return ss.str();
    }
};

class ReservationQueue {
private:
    int arr[100];
    int front;
    int rear;

public:
    ReservationQueue() {
        front = 0;
        rear = -1;
    }

    bool enqueueReservation(int memberID) {
        if (rear == 99)
            return false;

        rear++;
        arr[rear] = memberID;
        return true;
    }

    string dequeueReservation() {
        if (front > rear)
            return "No reservations found.";

        stringstream ss;
        ss << "Book assigned to Member ID: " << arr[front];
        front++;

        return ss.str();
    }
};

MemberList members;
BookBST books;
BorrowHistory history;
ReturnStack returnsStack;
ReservationQueue reservations;

HWND hMemberId, hName, hEmail, hPhone, hAddress;
HWND hBookId, hTitle, hAuthor, hCopies;
HWND hBorrowMemberId, hBorrowBookId, hBorrowDate;
HWND hReturnBookId, hReservationMemberId;
HWND hOutput;

string getText(HWND hwnd) {
    char buffer[300];
    GetWindowTextA(hwnd, buffer, 300);
    return string(buffer);
}

int getInt(HWND hwnd) {
    string value = getText(hwnd);
    if (value.empty())
        return 0;
    return stoi(value);
}

void setOutput(string text) {
    SetWindowTextA(hOutput, text.c_str());
}
bool validateField(HWND field, string fieldName) {

    string value = getText(field);

    if (value.empty()) {

        string message = fieldName + " is required.";

        MessageBoxA(
            NULL,
            message.c_str(),
            "Validation Warning",
            MB_OK | MB_ICONWARNING
        );

        SetFocus(field);

        return false;
    }

    return true;
}

LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {

    switch (msg) {

    case WM_CREATE:

        CreateWindowA("STATIC", "Member ID:", WS_VISIBLE | WS_CHILD, 20, 50, 100, 25, hwnd, NULL, NULL, NULL);
        hMemberId = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 120, 50, 180, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("STATIC", "Name:", WS_VISIBLE | WS_CHILD, 20, 85, 100, 25, hwnd, NULL, NULL, NULL);
        hName = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 120, 85, 180, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("STATIC", "Email:", WS_VISIBLE | WS_CHILD, 20, 120, 100, 25, hwnd, NULL, NULL, NULL);
        hEmail = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 120, 120, 180, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("STATIC", "Phone:", WS_VISIBLE | WS_CHILD, 20, 155, 100, 25, hwnd, NULL, NULL, NULL);
        hPhone = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 120, 155, 180, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("STATIC", "Address:", WS_VISIBLE | WS_CHILD, 20, 190, 100, 25, hwnd, NULL, NULL, NULL);
        hAddress = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 120, 190, 180, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("BUTTON", "Add Member", WS_VISIBLE | WS_CHILD, 20, 230, 135, 35, hwnd, (HMENU)1, NULL, NULL);
        CreateWindowA("BUTTON", "Search Member", WS_VISIBLE | WS_CHILD, 165, 230, 135, 35, hwnd, (HMENU)2, NULL, NULL);
        CreateWindowA("BUTTON", "Remove Member", WS_VISIBLE | WS_CHILD, 20, 275, 135, 35, hwnd, (HMENU)3, NULL, NULL);
        CreateWindowA("BUTTON", "Display Members", WS_VISIBLE | WS_CHILD, 165, 275, 135, 35, hwnd, (HMENU)4, NULL, NULL);

        CreateWindowA("STATIC", "Book ID:", WS_VISIBLE | WS_CHILD, 350, 50, 100, 25, hwnd, NULL, NULL, NULL);
        hBookId = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 450, 50, 180, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("STATIC", "Title:", WS_VISIBLE | WS_CHILD, 350, 85, 100, 25, hwnd, NULL, NULL, NULL);
        hTitle = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 450, 85, 180, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("STATIC", "Author:", WS_VISIBLE | WS_CHILD, 350, 120, 100, 25, hwnd, NULL, NULL, NULL);
        hAuthor = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 450, 120, 180, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("STATIC", "Copies:", WS_VISIBLE | WS_CHILD, 350, 155, 100, 25, hwnd, NULL, NULL, NULL);
        hCopies = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 450, 155, 180, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("BUTTON", "Add Book", WS_VISIBLE | WS_CHILD, 350, 195, 135, 35, hwnd, (HMENU)5, NULL, NULL);
        CreateWindowA("BUTTON", "Search Book", WS_VISIBLE | WS_CHILD, 495, 195, 135, 35, hwnd, (HMENU)6, NULL, NULL);
        CreateWindowA("BUTTON", "Remove Book", WS_VISIBLE | WS_CHILD, 350, 240, 135, 35, hwnd, (HMENU)7, NULL, NULL);
        CreateWindowA("BUTTON", "Display/Sort Books", WS_VISIBLE | WS_CHILD, 495, 240, 135, 35, hwnd, (HMENU)8, NULL, NULL);

        /* Borrow History */
        CreateWindowA("STATIC", "Borrow Member ID:", WS_VISIBLE | WS_CHILD, 680, 50, 130, 25, hwnd, NULL, NULL, NULL);
        hBorrowMemberId = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 820, 50, 150, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("STATIC", "Borrow Book ID:", WS_VISIBLE | WS_CHILD, 680, 85, 130, 25, hwnd, NULL, NULL, NULL);
        hBorrowBookId = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 820, 85, 150, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("STATIC", "Borrow Date:", WS_VISIBLE | WS_CHILD, 680, 120, 130, 25, hwnd, NULL, NULL, NULL);
        hBorrowDate = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 820, 120, 150, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("BUTTON", "Add Borrow", WS_VISIBLE | WS_CHILD, 680, 160, 140, 35, hwnd, (HMENU)9, NULL, NULL);
        CreateWindowA("BUTTON", "View History", WS_VISIBLE | WS_CHILD, 830, 160, 140, 35, hwnd, (HMENU)10, NULL, NULL);

        CreateWindowA("STATIC", "Return Book ID:", WS_VISIBLE | WS_CHILD, 680, 220, 130, 25, hwnd, NULL, NULL, NULL);
        hReturnBookId = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 820, 220, 150, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("BUTTON", "Push Return", WS_VISIBLE | WS_CHILD, 680, 255, 140, 35, hwnd, (HMENU)11, NULL, NULL);
        CreateWindowA("BUTTON", "Process Return", WS_VISIBLE | WS_CHILD, 830, 255, 140, 35, hwnd, (HMENU)12, NULL, NULL);

        CreateWindowA("STATIC", "Reservation Member ID:", WS_VISIBLE | WS_CHILD, 680, 315, 150, 45, hwnd, NULL, NULL, NULL);
        hReservationMemberId = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 840, 315, 130, 25, hwnd, NULL, NULL, NULL);

        CreateWindowA("BUTTON", "Add Reservation", WS_VISIBLE | WS_CHILD, 680, 360, 140, 35, hwnd, (HMENU)13, NULL, NULL);
        CreateWindowA("BUTTON", "Process Reservation", WS_VISIBLE | WS_CHILD, 830, 360, 140, 35, hwnd, (HMENU)14, NULL, NULL);
        CreateWindowA("STATIC", "Output:", WS_VISIBLE | WS_CHILD, 20, 330, 100, 25, hwnd, NULL, NULL, NULL);

        hOutput = CreateWindowA("EDIT", "",
                                WS_VISIBLE | WS_CHILD | WS_BORDER |
                                ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL,
                                20, 360, 650, 260,
                                hwnd, NULL, NULL, NULL);

        break;

    case WM_COMMAND:

        try {
            if (LOWORD(wp) == 1) {

                if (!validateField(hMemberId, "Member ID")) break;
                if (!validateField(hName, "Name")) break;
                if (!validateField(hEmail, "Email")) break;
                if (!validateField(hPhone, "Phone")) break;
                if (!validateField(hAddress, "Address")) break;

                members.addMember(
                    getInt(hMemberId),
                    getText(hName),
                    getText(hEmail),
                    getText(hPhone),
                    getText(hAddress)
                );

                setOutput("Member added successfully.");
            }

            else if (LOWORD(wp) == 2) {
                setOutput(members.searchMember(getInt(hMemberId)));
            }

            else if (LOWORD(wp) == 3) {
                bool removed = members.removeMember(getInt(hMemberId));
                setOutput(removed ? "Member removed successfully." : "Member not found.");
            }

            else if (LOWORD(wp) == 4) {
                setOutput(members.displayMembers());
            }

            else if (LOWORD(wp) == 5) {
                if (!validateField(hBookId, "Book ID")) break;
                if (!validateField(hTitle, "Title")) break;
                if (!validateField(hAuthor, "Author")) break;
                if (!validateField(hCopies, "Copies")) break;
                books.addBook(
                    getInt(hBookId),
                    getText(hTitle),
                    getText(hAuthor),
                    getInt(hCopies)
                );
                setOutput("Book added successfully.");
            }

            else if (LOWORD(wp) == 6) {
                setOutput(books.searchBook(getInt(hBookId)));
            }

            else if (LOWORD(wp) == 7) {
                bool removed = books.removeBook(getInt(hBookId));
                setOutput(removed ? "Book removed successfully." : "Book not found.");
            }

            else if (LOWORD(wp) == 8) {
                setOutput(books.displayBooksSorted());
            }

            else if (LOWORD(wp) == 9) {
                if (!validateField(hBorrowMemberId, "Borrow Member ID")) break;
                if (!validateField(hBorrowBookId, "Borrow Book ID")) break;
                if (!validateField(hBorrowDate, "Borrow Date")) break;
                history.addBorrowRecord(
                    getInt(hBorrowMemberId),
                    getInt(hBorrowBookId),
                    getText(hBorrowDate)
                );
                setOutput("Borrow record added successfully.");
            }

            else if (LOWORD(wp) == 10) {
                setOutput(history.viewHistory(getInt(hBorrowMemberId)));
            }

            else if (LOWORD(wp) == 11) {
                if (!validateField(hReturnBookId, "Return Book ID")) break;
                bool ok = returnsStack.pushReturn(getInt(hReturnBookId));
                setOutput(ok ? "Returned book pushed to stack." : "Return stack is full.");
            }

            else if (LOWORD(wp) == 12) {
                if (!validateField(hReturnBookId, "Return Book ID")) break;
                setOutput(returnsStack.processReturn());
            }

            else if (LOWORD(wp) == 13) {
                if (!validateField(hReservationMemberId, "Reservation Member ID")) break;
                bool ok = reservations.enqueueReservation(getInt(hReservationMemberId));
                setOutput(ok ? "Reservation added to queue." : "Reservation queue is full.");
            }

            else if (LOWORD(wp) == 14) {
                if (!validateField(hReservationMemberId, "Reservation Member ID")) break;
                setOutput(reservations.dequeueReservation());
            }
        }
        catch (...) {
            setOutput("Invalid input. Please enter numbers in ID fields.");
        }

        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    }

    return DefWindowProcA(hwnd, msg, wp, lp);
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR args, int ncmdshow) {

    WNDCLASSA wc = {0};

    wc.hbrBackground = (HBRUSH)COLOR_WINDOW;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hInstance = hInst;
    wc.lpszClassName = "LibraryGUI";
    wc.lpfnWndProc = WindowProcedure;

    if (!RegisterClassA(&wc))
        return -1;

    CreateWindowA(
        "LibraryGUI",
        "Library Management System",
        WS_OVERLAPPEDWINDOW | WS_VISIBLE,
        100, 50, 1020, 700,
        NULL, NULL, NULL, NULL
    );

    MSG msg = {0};

    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}